# lsc-case-study

Following files have been placed in the zip folder:
###################################################

1_Assignment_Questions-NVN.docx       (Word Document)
2_Lead-scoring-case-study-NVN.ipynb   (Jupyter Notebook File)
3_Lead-scoring-presentation-NVN.pdf   (PDF File)
4_Lead-scoring-summary-NVN.pdf        (PDF File)
5_README-NVN.md                       (MarkDown(md) File)

# This is the group study project which has been collectively prepared by following members:
# Narayana Murthy Raju
# Vivek Dhar
# Neeraj Sharma